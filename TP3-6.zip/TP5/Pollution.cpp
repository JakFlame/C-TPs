#include<iostream>
#include"Pollution.hpp"
using namespace std;

PollutingProject::PollutingProject(int id){
    mId = id;
    for (int i = 0; i < 5; i++){
        mPollutionMeasures[i] = -1;
    }
}

void PollutingProject::addMeasure(int n){
    bool is_full = false;
    for (int i = 0; i < 5; i++){
        if (mPollutionMeasures[i] == -1) { mPollutionMeasures[i] = n; }
        is_full = true;
        break;
    }
    if (is_full == false) {
        for (int j = 0; j < 4; j++){
            mPollutionMeasures[j] = mPollutionMeasures[j+1];
        }
        mPollutionMeasures[4] = n;
    }
}

void PollutingProject::displayMeasures(){
    cout << "Valeurs mesurees (en tonnes) de rejets dans l'air pour le projet " << mId << " : ";
    for (int i = 0; i < 5; i++){
        if (mPollutionMeasures[i] >= 0){ cout << mPollutionMeasures[i] << ", "; }
        else { break; }
    }
    cout << endl;
}

double PollutingProject::mean(){
    double somme = 0; int cmp = 0;
    for (int i = 0; i < 5; i++){
        if (mPollutionMeasures[i] >= 0){ somme += mPollutionMeasures[i]; cmp++; }
        else { break; }
    }
    if (cmp == 0){ return 0; }
    else { return(somme / cmp); }
}

bool PollutingProject::worseThan(PollutingProject project){
    double a = mean();
    double b = project.mean();
    if (a >= b){ return true; }
    else { return false; }
}



PollutingProject::PollutingProject(){
    mId = -1;
    for (int i = 0; i < 5; i++){
        mPollutionMeasures[i] = -1;
    }
}

int PollutingProject::getID(){
    return mId;
}

PollutingProjectsAnalyzer::PollutingProjectsAnalyzer(){
    mSize = 0;
    for (int i = 0; i < 100; i++){
        mProjects[i] = PollutingProject();
    }
    mWorst = nullptr;
}

int PollutingProjectsAnalyzer::addNewProject(){
    for (int i = 0; i < 100; i++){
        if (mProjects[i].getID() == -1){
            mProjects[i] = PollutingProject(i);
            mSize++;
            return i;
        }
    }
    return -1;
}

void PollutingProjectsAnalyzer::addMeasure(int val, int id){
    mProjects[id].addMeasure(val);
    if (mWorst == nullptr){
        mWorst = &mProjects[id];
    }
    else {
        if (mProjects[id].worseThan(*mWorst)){
            mWorst = &mProjects[id];
        }
    }
}

int PollutingProjectsAnalyzer::getWorstId(){
    if (mWorst != nullptr){
        return mWorst->getID();
    }
    else {
        return -1;
    }
}