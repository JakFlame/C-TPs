#ifndef LAMP_HPP
#define LAMP_HPP

class Lamp
{
    bool mIsOn;
    int mColor;
    
    public : 
        Lamp();
        Lamp(bool isOn);
        //exo_1.4 et 1.4_bis
        Lamp( bool isOn, int color);
        
        void printColor();
        //exo_1.2
        bool isOn();
        //exo_1.5
        void Switch();
        //exo_1.6
        void changeColor();
};

#endif