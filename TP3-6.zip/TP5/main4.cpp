#include<iostream>
#include"Pollution.hpp"
using namespace std;

int main(){
    cout << endl;

    PollutingProjectsAnalyzer analyzer;

    analyzer.addNewProject();
    for (int i = 0; i < 3; i++){
        analyzer.addMeasure(i, 0);
    }
    analyzer.addNewProject();
    for (int i = 0; i < 4; i++){
        analyzer.addMeasure(i, 1);
    }
    analyzer.addNewProject();
    for (int i = 0; i < 5; i++){
        analyzer.addMeasure(i, 2);
    }

    cout << analyzer.getWorstId() << endl;




    cout << endl;
    return 0;
}