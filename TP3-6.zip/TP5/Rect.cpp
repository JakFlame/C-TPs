#include<iostream>
#include"Rect.hpp"
using namespace std;

Rectangle::Rectangle(float h, float w){
    height = h;
    width = w;
}

float Rectangle::getHeight(){
    return height;
}

float Rectangle::getWidth(){
    return width;
}

float Rectangle::getArea(){
    return(height * width);
}

bool Rectangle::isSquare(){
    if (height == width){ return true; }
    else { return false; }
}