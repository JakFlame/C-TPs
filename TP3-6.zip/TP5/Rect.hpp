#ifndef RECT_HPP
#define RECT_HPP

class Rectangle
{
    private:
        float height;
        float width;

    public:
        Rectangle(float h, float w);

        float getHeight();
        float getWidth();
        float getArea();
        bool isSquare();
};

#endif