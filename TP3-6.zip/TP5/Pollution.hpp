#ifndef POLLUTION_HPP
#define POLLUTION_HPP

class PollutingProject
{
    private:
        int mId;
        int mPollutionMeasures[5];

    public:
        PollutingProject(int id);
        PollutingProject();

        void addMeasure(int n);
        void displayMeasures();
        double mean();
        bool worseThan(PollutingProject project);
        int getID();

};

class PollutingProjectsAnalyzer
{
    private:
        PollutingProject mProjects[100];
        int mSize;
        PollutingProject *mWorst;

    public:
        PollutingProjectsAnalyzer();
        int addNewProject();
        void addMeasure(int val, int id);
        int getWorstId();

};

#endif