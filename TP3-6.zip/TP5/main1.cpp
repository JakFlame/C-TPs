#include<iostream>
#include"Lamp.hpp"
using namespace std;

int main(){
    cout << endl;


    //exo_1.1
    Lamp Light;
    Light.printColor();
    //exo_1.2
    cout << endl;
    bool check_lamp_state = Light.isOn();
    if (!check_lamp_state) { cout << "La lampe est actuellement eteinte." << endl; }
    else { cout << "La lampe est actuellemt allumee." << endl; }
    //exo1.3
    cout << endl;
    Lamp Light2(true);
    bool check_lamp2_state = Light2.isOn();
    if (check_lamp2_state) { cout << "La lampe est actuellemt allumee." << endl; }
    else { cout << "La lampe est actuellement eteinte." << endl; } 
    //exo1.4
    cout << endl;
    Lamp Light3(false, 3);
    Light3.printColor();
    //exo_1.4_bis
    cout << endl;
    int lamp_color;
    cout << "Quelle couleur a l'allumage : "; cin >> lamp_color;
    Lamp Light4(true, lamp_color);
    Light4.printColor();
    //exo_1.5
    cout << endl;
    Lamp Light5(true);
    bool check_lamp5_state = Light5.isOn();
    if (!check_lamp5_state) { cout << "La lampe est actuellement eteinte." << endl; }
    else { cout << "La lampe est actuellemt allumee." << endl; }
    Light5.Switch();
    check_lamp5_state = Light5.isOn();
    if (!check_lamp5_state) { cout << "La lampe est actuellement eteinte." << endl; }
    else { cout << "La lampe est actuellemt allumee." << endl; }
    //exo_1.6
    cout << endl;
    Lamp Light6(false, 1);
    bool check_lamp6_state = Light6.isOn();
    if (!check_lamp6_state) { cout << "La lampe est actuellement eteinte." << endl; }
    else { cout << "La lampe est actuellemt allumee." << endl; }
    Light6.Switch();
    check_lamp6_state = Light6.isOn();
    if (!check_lamp6_state) { cout << "La lampe est actuellement eteinte." << endl; }
    else { cout << "La lampe est actuellemt allumee." << endl; }
    for (int i = 0; i < 10; i++){
        Light6.changeColor();
        Light6.printColor();
    }
    Light6.Switch();
    check_lamp6_state = Light6.isOn();
    if (!check_lamp6_state) { cout << "La lampe est actuellement eteinte." << endl; }
    else { cout << "La lampe est actuellemt allumee." << endl; }
    //exo_1.7
    cout << endl;
    Lamp Light7(false, 2);
    Light7.printColor();
    Light7.Switch();
    Light7.printColor();
    Light7.Switch();
    Light7.changeColor();
    Light7.Switch();
    Light7.printColor();


    cout << endl;
    return 0;
}