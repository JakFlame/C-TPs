#include<iostream>
#include"Rect.hpp"
using namespace std;

int main(){
    cout << endl;


    Rectangle Rect(6.68, 8.3);
    cout << "Largeur du rectangle : " << Rect.getWidth() << endl;
    cout << "Hauteur du rectangle : " << Rect.getHeight() << endl;
    cout << "Surface : " << Rect.getArea() << endl;
    if (Rect.isSquare()){
        cout << "La forme est un carre" << endl;
    }
    else {
        cout << "La forme n'est pas un carre" << endl;
    }


    cout << endl;
    return 0;
}