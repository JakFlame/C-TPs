#include<iostream>
#include"Matrix.hpp"
using namespace std;

Matrix::Matrix(){
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 3; j++){
            matrice[i][j] = 0;
        }
    }
}

void Matrix::fillMatrix(){
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 3; j++){
            cout << "Ligne " << i + 1 << " nombre " << j + 1 << " : "; cin >> matrice[i][j];
        }
    }
    cout << endl;
}

void Matrix::display(){
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 3; j++){
            cout << matrice[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

int Matrix::diagSum(){
    int somme = 0;
    for (int i = 0; i < 3; i++){
        somme += matrice[i][i];
    }
    return somme;
}