#ifndef MATRIX_HPP
#define MATRIX_HPP

class Matrix
{
    private:
        int matrice[3][3];

    public:
        Matrix();

        void fillMatrix();
        void display();
        int diagSum();
};

#endif