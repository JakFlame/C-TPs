#include<iostream>
#include"Matrix.hpp"
using namespace std;

int main(){
    cout << endl;


    Matrix Matrice;
    Matrice.fillMatrix();
    Matrice.display();
    cout << "La somme de la diagonal : " << Matrice.diagSum() << endl;


    cout << endl;
    return 0;
}