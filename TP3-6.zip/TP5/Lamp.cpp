#include<iostream>
#include"Lamp.hpp"
using namespace std;

Lamp::Lamp()
{
    mIsOn = false;
    mColor = 0;
}

Lamp::Lamp( bool isOn)
{
    mIsOn = isOn;
    mColor = 0;
}

//exo_1.4
/* Lamp::Lamp( bool isOn, int color)
{
    mIsOn = isOn;
    if (color > 5) { color = 0; }
    mColor = color;
} */

//exo_1.4_bis
Lamp::Lamp( bool isOn, int color)
{
    mIsOn = isOn;
    if (color >= 4) { color = 0; }
    mColor = color;
}

/* void Lamp::printColor()
{
    if(mColor == 0)
    {
        cout << "Couleur blanche" << endl;
    }
    else if (mColor == 1)
    {
        cout << "Couleur rouge" << endl;
    }
    else if (mColor == 2)
    {
        cout << "Couleur vert" << endl;
    }
    else if (mColor == 3)
    {
        cout << "Couleur jaune" << endl;
    }
    else if (mColor == 4)
    {
        cout << "Couleur bleu" << endl;
    }
    else if (mColor == 5)
    {
        cout << "Couleur violet" << endl;
    }
} */

//exo_1.7
void Lamp::printColor()
{
    if (mIsOn){
        if(mColor == 0)
        {
            cout << "Couleur blanche" << endl;
        }
        else if (mColor == 1)
        {
            cout << "Couleur rouge" << endl;
        }
        else if (mColor == 2)
        {
            cout << "Couleur vert" << endl;
        }
        else if (mColor == 3)
        {
            cout << "Couleur jaune" << endl;
        }
        else if (mColor == 4)
        {
            cout << "Couleur bleu" << endl;
        }
        else if (mColor == 5)
        {
            cout << "Couleur violet" << endl;
        }
    }
    else {
        cout << "La lampe est eteinte." << endl;
    }
}

//exo_1.2
bool Lamp::isOn()
{
    return mIsOn;
}

//exo_1.5
void Lamp::Switch()
{
    mIsOn = !mIsOn;
}

//exo_1.6
/* void Lamp::changeColor()
{
    mColor++;
    if (mColor > 5) { mColor = 0; }
} */

//exo_1.7
void Lamp::changeColor()
{
    if (mIsOn){
        mColor++;
        if (mColor > 5) { mColor = 0; }
    }
}