#include<iostream>
#include<cstdlib>
#include"array.hpp"

using namespace std;

//exo_1.1_ter
void displayArray(int tab[], int size){
    for (int i = 0; i < size; i++){ if (i == size - 1){ cout << tab[i] << endl; } else { cout << tab[i] << ", "; } }
}
//exo_1.2
void displayArray(double tab[], int size){
    for (int i = 0; i < size; i++){ if (i == size - 1){ cout << tab[i] << endl; } else { cout << tab[i] << ", "; } }
}
//exo_2.1
void initializeTable(int tab[], int size, int multiplier){
    for (int i = 0; i < size; i++){ tab[i] = i * multiplier; }
}
//exo_2.2
void fillArrayWithRandNum(int tab[], int size, int min, int max){
    for (int i = 0; i < size; i++){
        int randNum = rand()% ( max - min + 1) + min; 
        tab[i] = randNum;
    }
}
//exo_2.3
bool isPrime(int x){
    if (x <= 1){ return false; }
    else if (x == 2){ return true; }
    else {
        for (int i = 2; i <= x / 2; i++){
            if (x % i == 0){ return false; }
        }
        return true;
    }
}
void fillArrayWithFirstPrimes(int tab[], int size){
    int number = 0;
    for (int i = 0; i < size; i++){
        while (isPrime(number) == false){
            number++;
        }
        tab[i] = number;
        number++;
    }
}
//exo_3.1
int getMin(int tab[], int size){
    int min;
    for (int i = 0; i < size; i++){
        if (i == 0){ min = tab[i]; }
        else { if (tab[i] < min){ min = tab[i]; } }
    }
    return min;
}
//exo_3.1_bis
void getMinMax(int tab[], int size, int* min, int* max){
    *min = tab[0]; *max = tab[0];
    for (int i = 1; i < size; i++){
        if (tab[i] < *min){ *min = tab[i]; }
        if (tab[i] > *max){ *max = tab[i]; }
    }
}
//exo_3.2
double mean(double tab[], int size){
    double somme = 0;
    for (int i = 0; i < size; i++){
        cout << "Donnez un note : "; cin >> tab[i];
        somme += tab[i];
    }
    return (somme / size);
}
//exo_3.3
bool contain(int tab[], int size, int x){
    for (int i = 0; i < size; i++){
        if (x == tab[i]){
            return true;
        }
    } return false;
}
//exo_3.4
int search(int tab[], int size, int x){
    for (int i = 0; i < size; i++){
        if (x == tab[i]){ return i; }
    } return -1;
}
//exo_3.5
int count(int tab[], int size, int x){
    int counter = 0;
    for (int i = 0; i < size; i++){
        if (x == tab[i]) { counter++; }
    } return counter;
}
//exo_3.5_bis
int searchInRange(int tab[], int size, int x, int a, int b){
    if (a < 0){ a = 0; } if (b >= size){ b = size; }
    for (int i = a; i < b; i++){
        if (x == tab[i]){
            return i;
        }
    } return -1;
}
int countWithSearch(int tab[], int size, int x){
    int search = searchInRange(tab, size, x, 0, size), counter = 0;
    while (search >= 0){
        counter++;
        search = searchInRange(tab, size, x, search + 1, size);
    }
    return counter;
}
//exo_4.1
void resetValue(int tab[], int size, int x){
    for (int i = 0; i < size; i++){
        if (tab[i] == x){
            tab[i] = 0;
        }
    }
}
//exo_4.2
void shiftArray(int tab[], int a, int b){
    for (int i = a; i < b - 1; i++){
        tab[i] = tab[i+1];
    }
}
void removeValue(int tab[], int* size, int x){
    int size_removal_counter = 0;
    for (int i = 0; i < *size; i++){
        if (tab[i] == x){
            shiftArray(tab, i, *size);
            size_removal_counter++;
            i--;
        }
    }
    *size -= size_removal_counter;
}
