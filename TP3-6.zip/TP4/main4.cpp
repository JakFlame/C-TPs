#include<iostream>
#include<cstdlib>
#include<ctime>
#include"array.hpp"
using namespace std;

int main(){
    cout << endl;
    srand(time(0));
    
    //exo_4.1
    int tab[8], x;
    fillArrayWithRandNum(tab, 8, 1, 10);
    cout << "Tabley avant modif : "; displayArray(tab, 8);
    cout << "Saisir un entier : "; cin >> x; resetValue(tab, 8, x);
    cout << "Tableu apres modif : "; displayArray(tab, 8); cout << endl;
    //exo_4.2
    int pizza[8], size = 8, tomato;
    fillArrayWithRandNum(pizza, size, 1, 10);
    cout << "Tabley avant modif : "; displayArray(pizza, size);
    cout << "Saisir un entier : "; cin >> tomato; removeValue(pizza, &size, tomato);
    cout << "Tableu apres modif : "; displayArray(pizza, size); cout << endl;


    cout << endl;
    return 0;
}