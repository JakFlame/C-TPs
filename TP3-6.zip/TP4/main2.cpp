#include<iostream>
#include<cstdlib>
#include<ctime>
#include"array.hpp"
using namespace std;

int main(){
    cout << endl;

    //exo_2.1
    int tab[100];
    initializeTable(tab, 100, 1);
    cout << "Le tableau apres initialisation des valeurs contient : "; displayArray(tab, 100); cout << endl;
    int Tab[100];
    initializeTable(Tab, 100, 2);
    cout << "Le tableau apres initialisation des valeurs contient : "; displayArray(Tab, 100); cout << endl;
    //exo_2.2
    srand(time(0));
    int TAB[20];
    fillArrayWithRandNum(TAB, 20, 0, 10);
    cout << "Le resultat de l'utilisation de fillArrayWithRandNum au TAB est : "; displayArray(TAB, 20); cout << endl;
    //exo_2.3
    int List[100];
    fillArrayWithFirstPrimes(List, 100);
    cout << "Voici les 100 premiers nombres premiers : "; displayArray(List, 100);

    cout << endl;
    return 0;
}