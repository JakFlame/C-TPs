#include<iostream>
#include"array.hpp"
using namespace std;

int main(){
    cout << endl;

    //exo_1.1
    int grades[5] = {13, 9, 16, 15, 19};
    cout << "Valeur du troisieme element : " << grades[2] << endl;
    grades[3] = 14;
    cout << "Tableau apres modification : " << grades[0] << ", " << grades[1] << ", " << grades[2] << ", " << grades[3] << ", " << grades[4] << endl << endl;
    //exo_1.1_bis
    int Grades[5] = {13, 9, 16, 15, 19};
    cout << "Le tableau contient : ";
    for (int i = 0; i < 5; i++){ if (i == 4){ cout << Grades[i] << endl << endl; } else { cout << Grades[i] << ", "; } }
    //exo_1.1_ter
    int GRADES[5] = {13, 9, 16, 15, 19};
    cout << "Le tableau contient : "; displayArray(GRADES, 5); cout << endl;
    //exo_1.2
    int first_tab[3] = {1,2,3};
    cout << "Le premier tableu contient : "; displayArray(first_tab, 3);

    double second_tab[6] = {1.5, 2.8, 0.7};
    cout << "Le deuxieme tableu contient : "; displayArray(second_tab, 6);
    second_tab[5] = 12.92;
    cout << "Le deuxieme tableu apres modification contient : "; displayArray(second_tab, 6);

    int third_tab[5];
    cout << "Le troisieme tableu contient : "; displayArray(third_tab, 5);
    third_tab[0] = 9; third_tab[1] = 4; third_tab[2] = 6; third_tab[3] = 8; third_tab[4] = 3;
    cout << "Le troisieme tableu apres assignation des valeurs contient : "; displayArray(third_tab, 5);

    int fourth_tab[3];
    for (int i = 0; i < 3; i++){
        cout << "Donnez la valeur pour case " << i << " : ";
        cin >> fourth_tab[i];
    }
    cout << "Le quatrieme tableu contient : "; displayArray(fourth_tab, 3); cout << endl;
    //exo_1.3
    int tab[100];
    cout << "Le tableau contient : "; displayArray(tab, 100); cout << endl;
    for (int i = 0; i < 100; i++){ tab[i] = i; }
    cout << "Le tableau apres initialisation des valeurs contient : "; displayArray(tab, 100); cout << endl;
    //exo_1.4
    int Tab[100];
    cout << "Le tableau contient : "; displayArray(Tab, 100); cout << endl;
    for (int i = 0; i < 100; i++){ Tab[i] = i * 2; }
    cout << "Le tableau apres initialisation des valeurs contient : "; displayArray(Tab, 100);

    cout << endl;
    return 0;
}

