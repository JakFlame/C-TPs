#ifndef ARRAY_HPP
#define ARRAY_HPP

//exo_1.1_ter
void displayArray(int tab[], int size);
//exo_1.2
void displayArray(double tab[], int size);
//exo_2.1
void initializeTable(int tab[], int size, int multiplier);
//exo_2.2
void fillArrayWithRandNum(int tab[], int size, int min, int max);
//exo_2.3
bool isPrime(int x);
void fillArrayWithFirstPrimes(int tab[], int size);
//exo_3.1
int getMin(int tab[], int size);
//exo_3.1_bis
void getMinMax(int tab[], int size, int* min, int* max);
//exo_3.2
double mean(double tab[], int size);
//exo_3.3
bool contain(int tab[], int size, int x);
//exo_3.4
int search(int tab[], int size, int x);
//exo_3.5
int count(int tab[], int size, int x);
//exo_3.5_bis
int searchInRange(int tab[], int size, int x, int a, int b);
int countWithSearch(int tab[], int size, int x);
//exo_4.1
void resetValue(int tab[], int size, int x);
//exo_4.2
void shiftArray(int tab[], int a, int b);
void removeValue(int tab[], int* size, int x);


#endif