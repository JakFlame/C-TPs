#include<iostream>
#include<cstdlib>
#include<ctime>
#include"array.hpp"
using namespace std;

int main(){
    cout << endl;
    srand(time(0));
    
    //exo_3.1
    int tab[8];
    fillArrayWithRandNum(tab, 8, 0, 100);
    cout << "Tableu : "; displayArray(tab, 8);
    int valMin = getMin(tab, 8);
    cout << "Plus petit : " << valMin << endl << endl;
    //exo_3.1_bis
    int Tab[8];
    int min, max;
    fillArrayWithRandNum(Tab, 8, 0, 10);
    cout << "Tableu : "; displayArray(Tab, 8);
    getMinMax(Tab, 8, &min, &max);
    cout << "Plus petit : " << min << endl;
    cout << "Plus grand : " << max << endl << endl;
    //exo_3.2
    double TAB[6], moyenne;
    moyenne = mean(TAB, 6);
    cout << "Notes : "; displayArray(TAB, 6);
    cout << "Moyenne : " << moyenne << endl << endl;
    //exo_3.3
    int List[15], n;
    fillArrayWithRandNum(List, 15, 0, 100);
    cout << "Saisir un entier : "; cin >> n;
    cout << "Tableu : "; displayArray(List, 15);
    bool contient = contain(List, 15, n);
    if (contient){ cout << n << " est dans le tableu." << endl << endl; }
    else { cout << n << " n'est pas dans le tableu." << endl << endl; }
    //exo_3.4
    int LIST[15], N;
    fillArrayWithRandNum(LIST, 15, 0, 20);
    cout << "Saisir un entier : "; cin >> N;
    cout << "Tableu : "; displayArray(LIST, 15);
    int trouve = search(LIST, 15, N);
    if (trouve >= 0){ cout << N << " se trouve a l'indice "<< trouve << " (case " << trouve +1 << ")." << endl << endl; }
    else { cout << N << " n'est pas dans le tableu." << endl << endl; }
    //exo_3.5
    int array[15], num;
    fillArrayWithRandNum(array, 15, 1, 10);
    cout << "Saisir un entier : "; cin >> num;
    cout << "Tableu : "; displayArray(array, 15);
    int counter = count(array, 15, num);
    cout << num << " est present " << counter << " fois." << endl << endl;
    //exo_3.5_bis
    counter = countWithSearch(array, 15, num);
    cout << num << " est present " << counter << " fois." << endl << endl;

    cout << endl;
    return 0;
}