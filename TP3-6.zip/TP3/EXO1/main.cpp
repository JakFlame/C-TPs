#include<iostream>
using namespace std;

int main(){

    //EXO_1.1
    int age = 12;
    int *pAge = & age;
    cout << "La valeur de age en direct : " << age << endl;
    cout << "La valeur vers laquelle pointe pAge : " << *pAge << endl;
    //EXO_1.2
    int age2 = 18;
    int *pAge2 = & age2;
    *pAge2 = 25;
    cout << "La valeur de age modifie avec le pointeur : " << age2 << endl;
    //EXO_1.3
    int age3;
    int *pAge3 = & age3;
    cout << "Saisir votre age : "; cin >> *pAge3;
    cout << "La valeur de age donne par l'utilisatuer : " << age3 << endl;
    //EXO_1.4
    double price = 100.50; double *pPrice = & price;
    bool isActive = true; bool *pIsActive = & isActive;
    *pPrice = 150.75; *pIsActive = false;
    cout << "La valeur de price modifie avec le pointeur : " << price << endl;
    cout << "La valeur de isActive modifie avec le pointeur : " << isActive << endl;

    return 0;
}