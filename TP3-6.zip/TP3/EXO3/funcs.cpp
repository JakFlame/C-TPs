#include<iostream>
#include"funcs.hpp"
using namespace std;

//EXO_3.1
void arithmetic(double a, double b, double *pSomme, double *pProduit){
    *pSomme = a + b;
    *pProduit = a * b; 
}
//EXO_3.2
void minMax(int a, int b, int c, int *min, int *max){
    if (a >= b and a >= c){ *max = a; }
    if (b >= a and b >= c){ *max = b; }
    if (c >= a and c >= b){ *max = c; }

    if (a <= b and a <= c){ *min = a; }
    if (b <= a and b <= c){ *min = b; }
    if (c <= a and c <= b){ *min = c; }
}
//EXO_3.3
void logic(bool a, bool b, bool *pAND, bool *pOR, bool *pXOR){
    if (a == true){
        if (b == true){ *pAND = true; *pOR = true; *pXOR = false; }
        else { *pAND = false; *pOR = true; *pXOR = true; }
    }
    else {
        if (b == true){ *pAND = false; *pOR = true; *pXOR = true; }
        else { *pAND = false; *pOR = false; *pXOR = false; }
    }
}