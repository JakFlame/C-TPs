#ifndef FUNCS_HPP
#define FUNCS_HPP

//EXO_3.1
void arithmetic(double a, double b, double *pSomme, double *pProduit);
//EXO_3.2
void minMax(int a, int b, int c, int *min, int *max);
//EXO_3.3
void logic(bool a, bool b, bool *pAND, bool *pOR, bool *pXOR);

#endif