#include<iostream>
#include"funcs.hpp"
using namespace std;

int main(){

    //EXO_3.1
    double a,b; double somme,produit = 0;
    cout << "Saisir a : "; cin >> a;
    cout << "Saisir b : "; cin >> b;
    arithmetic(a, b, &somme, &produit);
    cout << "Somme = " << somme << endl;
    cout << "Produit = " << produit << endl;
    //EXO_3.2
    int A,B,C; int min,max;
    cout << "Saisir A : "; cin >> A;
    cout << "Saisir B : "; cin >> B;
    cout << "Saisir C : "; cin >> C;
    minMax(A,B,C,&min,&max);
    cout << "Le minimum vaut " << min << " et le maximum vaut " << max << endl;
    //EXO_3.3
    bool x,y; bool AND, OR, XOR;
    cout << "Premier valeur : "; cin >> x;
    cout << "Second valeur : "; cin >> y;
    logic(x, y, &AND, &OR, &XOR);
    cout << "Resultats : " << endl;
    cout << "AND : " << AND << endl;
    cout << "OR : " << OR << endl;
    cout << "XOR : " << XOR << endl;

    return 0;
}