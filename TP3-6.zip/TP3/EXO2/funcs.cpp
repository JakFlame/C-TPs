#include<iostream>
#include"funcs.hpp"
using namespace std;

//EXO_2.1
void addOne(int *pNumber){
    *pNumber += 1;
}
//EXO_2.2
void getOpposite(int *pNum){
    *pNum = -*pNum;
}
//EXO_2.3 et 2.3_BIS
bool isPositive(double x){
    if (x >= 0){ return true; }
    else { return false; }
}
void modify(double *pX){
    if (isPositive(*pX)){ *pX /= 2; }
    else { *pX *= 3; }
}
//EXO_2.4
void distributeBonus(double *pA, double *pB, double *pC, double bonus){
    bonus = bonus / 3;
    *pA += bonus; *pB += bonus; *pC += bonus;
}
//EXO_2.5 et 2.5_BIS
bool check(double min, double max){
    if (max > min){ return true; }
    else { return false; }
}
void modify(double *pMin, double *pMax){
    *pMin *= 2; *pMax /= 2;
}
void swap(double *pMin, double *pMax){
    double tmp;
    if (check(*pMin,*pMax) == false){
        tmp = *pMin;
        *pMin = *pMax;
        *pMax = tmp;
    }
}
//EXO_2.6
void sort(double *pA, double *pB, double *pC){
    swap(pB,pA);
    swap(pC,pB);
    swap(pB,pA);
}
