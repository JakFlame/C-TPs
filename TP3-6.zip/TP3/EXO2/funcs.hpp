#ifndef FUNCS_HPP
#define FUNCS_HPP

//EXO_2.1
void addOne(int *pNumber);
//EXO_2.2
void getOpposite(int *pNum);
//EXO_2.3 et 2.3_BIS
bool isPositive(double x);
void modify(double *pX);
//EXO_2.4
void distributeBonus(double *pA, double *pB, double *pC, double bonus);
//EXO_2.5 et 2.5_BIS
bool check(double min, double max);
void modify(double *pMin, double *pMax);
void swap(double *pMin, double *pMax);
//EXO_2.6
void sort(double *pA, double *pB, double *pC);

#endif