#include<iostream>
#include"funcs.hpp"
using namespace std;

int main(){

    //EXO_2.1
    int age;
    cout<<"Quel age avez vous : "; cin >> age;
    addOne(& age);
    cout<<"Votre age l'an prochain : "<< age <<endl;
    //EXO_2.2
    int num;
    cout << "Saisir un nombre : "; cin >> num;
    getOpposite(& num);
    cout << "L'oppose est : " << num << endl;
    //EXO_2.3 et 2.3_BIS
    double x;
    cout << "Saisir un nombre : "; cin >> x;
    modify(& x);
    cout << "Valeur finale : " << x << endl;
    //EXO_2.4
    double a,b,c; double bonus;
    cout << "Salaire du premier salarie : "; cin >> a;
    cout << "Salaire du second salarie : "; cin >> b;
    cout << "Salaire du troisième salarie : "; cin >> c; 
    cout << "Valeur de bonus : "; cin >> bonus; cout << endl;
    distributeBonus(&a,&b,&c,bonus);
    cout << "Salaire total des salaries : " << a << ", " << b << ", " << c << endl;
    //EXO_2.5 et 2.5_BIS
    double min,max;
    cout << "Entrez le min : "; cin >> min;
    cout << "Entrez le max : "; cin >> max;
    if (check(min,max) == false){
        swap(&min,&max);
        cout << "min et max inverses automatiquement pour non respect de la consigne." << endl;
    }
    else {
        cout << "Vos nombres sont corrects." << endl;
    }
    modify(&min,&max);
    if (check(min,max)){
        cout << "Resultat min = " << min << " et max = " << max << " (ils respectent l'ordre.)" << endl;
    }
    else {
        swap(&min,&max);
        cout << "Resultat min = " << min << " et max = " << max << " (ces nombres ont été inverses automatiquement suite a la modification)" << endl;
    }
    //EXO_2.6
    double A,B,C;
    cout << "Valeur de A : "; cin >> A;
    cout << "Valeur de B : "; cin >> B;
    cout << "Valeur de C : "; cin >> C;
    sort(&A,&B,&C);
    cout << "Apres tri : A = " << A << ", B = " << B << ", C = " << C << endl;

    return 0;
}