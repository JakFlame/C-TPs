#include<iostream>
#include<cstdlib>
#include<ctime>
#include"funcs.hpp"
#include"Census.hpp"
#include"Matrice.hpp"
using namespace std;

int main(){
    cout << endl;

    //exo_1
    int* pI;
    pI = new int;
    *pI = 42;
    cout << *pI << endl << pI << endl;
    delete pI;
    pI = nullptr;
    cout << endl;

    //exo_2
    srand(time(0));
    int taille;
    cout << "Donnez la taille de tableu : "; cin >> taille;
    double* arr = new double[taille];
    for (int i = 0; i < taille; i++){
        arr[i] = (rand()%(100-0+1)) + 0; //I want to give it a random value from 0 to 100
    }
    for (int i = 0; i < taille; i++){
        cout << arr[i] << " ";
    } cout << endl << endl;
    delete[] arr;
    arr = nullptr;

    //exo_2_bis
    int length;
    cout << "Donnez la taille de tableu dynamique : "; cin >> length;
    double* tab = dynamicArr(length);
    for (int i = 0; i < length; i++){
        tab[i] = (rand()%(100-0+1)) + 0;
    }
    for (int i = 0; i < length; i++){
        cout << tab[i] << " ";
    } cout << endl << endl;
    delete[] tab;
    tab = nullptr;

    //exo_3
    int table[10] = {12,-7,-9,0,0,3,67,-8,-1,4};
    int posSize;
    int* posTable = getPositiveValues(table, 10, &posSize);
    for (int i = 0; i < posSize; i++){
        cout << posTable[i] << " ";
    } cout << endl << endl;
    delete[] posTable;
    posTable = nullptr;

    //exo_5
    int* p = nullptr;
    reallocateMemory(&p, 3);
    cout << *p << "      " << p << endl;
    reallocateMemory(&p, 7);
    cout << *p << "      " << p << endl;
    reallocateMemory(&p, 9);
    cout << *p << "      " << p << endl;
    reallocateMemory(&p, 0);
    cout << *p << "      " << p << endl;
    reallocateMemory(&p, 8);
    cout << *p << "      " << p << endl;
    reallocateMemory(&p, 4);
    cout << *p << "      " << p << endl << endl;
    delete p;

    //exo_6
    Census bird(3);
    bird.addCensus(0, 6);
    bird.addCensus(1, 34);
    bird.addCensus(2, 576);
    for (int i = 0; i < bird.getSize(); i++){
        cout << bird.getNbCensusJour(i) << endl;
    } cout << endl;

    //exo_7
    Matrice Matrix(3,4);
    Matrix.fillRandom();
    Matrix.display();

    //exo_8
    int current_size = 0, max_size = 3;
    int* list = new int[max_size];
    int x;
    for (int i = 0; i < 12; i++){
        cout << "Donnez une valeur : "; cin >> x;
        addValue(&list, &current_size, &max_size, x);
        displayArray(list, current_size);
    }
    delete[] list;



    cout << endl;
    return 0;
}