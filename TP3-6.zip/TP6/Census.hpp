#ifndef CENSUS_HPP
#define CENCUS_HPP

class Census {
    private:
        int* pCensusRepereParJour;
        int size;
    public:
        Census(int days);
        void addCensus(int day, int spotted);
        int getSize();
        int getNbCensusJour(int day);
        ~Census();
};

#endif