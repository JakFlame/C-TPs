#include<iostream>
#include<cstdlib>
#include<ctime>
#include"funcs.hpp"
using namespace std;

//exo_2_bis
double* dynamicArr(int size){
    double* arr = new double[size];
    return arr;
}

 //exo_3
int* getPositiveValues(int tab[], int size, int* posSize){
    int* arr = new int[size];
    int counter = 0;
    for (int i = 0; i < size; i++){
        if (tab[i] >= 0){
            arr[counter] = tab[i];
            counter++;
        }
    }
    int* dynArr = new int[counter];
    for (int i = 0; i < counter; i++){
        dynArr[i] = arr[i];
    }
    *posSize = counter;
    delete[] arr;
    return dynArr;
}

//exo_5
void reallocateMemory(int** p, int value){
    if (*p != nullptr){
        delete *p;
    }
    *p = new int(value);
}

//exo_8
void displayArray(int* tab, int currentSize){
    for (int i = 0; i < currentSize; i++){
        cout << tab[i] << endl;
    } cout << endl;
}
void copyArray(int** oldTab, int* size){
    int newSize = *size += 3;
    int* newArr = new int[newSize];
    for (int i = 0; i < *size; i++){
        newArr[i] = (*oldTab)[i];
    }
    *size = newSize;
    delete[] *oldTab;
    *oldTab = newArr;
}
void addValue(int** tab, int* currentSize, int* size, int x){
    if (*currentSize == *size){
        copyArray(tab, size);
    }
    (*tab)[*currentSize] = x;
    *currentSize += 1;
}