#ifndef Matrice_HPP
#define Matrice_HPP

class Matrice {
    private:
        double** pMatrix;
        int mHeight;
        int mWidth;
    public:
        Matrice(int x, int y);
        ~Matrice();
        void fillRandom();
        void display();
};

#endif