#ifndef FUNCS_HPP
#define FUNCS_HPP

//exo_2_bis
double* dynamicArr(int size);
//exo_3
int* getPositiveValues(int tab[], int size, int* posSize);
//exo_5
void reallocateMemory(int** p, int value);
//exo_8
void displayArray(int* tab, int currentSize);
void copyArray(int** oldTab, int* size);
void addValue(int** tab, int* currentSize, int* size, int x);


#endif