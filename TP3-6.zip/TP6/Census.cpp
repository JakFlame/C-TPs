#include<iostream>
#include"Census.hpp"
using namespace std;

Census::Census(int days){
    pCensusRepereParJour = new int[days];
    size = days;
}

void Census::addCensus(int day, int spotted){
    pCensusRepereParJour[day] = spotted;
}

int Census::getSize(){
    return size;
}

int Census::getNbCensusJour(int day){
    return pCensusRepereParJour[day];
}

Census::~Census(){
    delete pCensusRepereParJour;
}