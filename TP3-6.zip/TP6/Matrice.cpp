#include<iostream>
#include<cstdlib>
#include<ctime>
#include"Matrice.hpp"
using namespace std;

Matrice::Matrice(int y, int x){
    pMatrix = new double*[y];
    for (int i = 0; i < y; i++){
        pMatrix[i] = new double[x];
    }
    mHeight = y; mWidth = x;
}

Matrice::~Matrice(){
    for (int i = 0; i < mHeight; i++){
        delete[] pMatrix[i];
    }
    delete[] pMatrix;
}

void Matrice::fillRandom(){
    for (int i = 0; i < mHeight; i++){
        for (int j = 0; j < mWidth; j++){
            pMatrix[i][j] = (rand()%(100-95+1)) + 95;
        }
    }
}

void Matrice::display(){
    for (int i = 0; i < mHeight; i++){
        for (int j = 0; j < mWidth; j++){
            cout << pMatrix[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}